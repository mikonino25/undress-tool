import os
import re
import time
import random
from typing import Optional
from datetime import datetime
import requests

# Ensure SSL verification works in restricted environments by pointing to certifi's CA bundle
import certifi
os.environ.setdefault("SSL_CERT_FILE", certifi.where())

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException, NoSuchWindowException

from temp_mail import create_temp_address, poll_for_message, read_message

# Always prefer the provided referral URL; allow override via env
REF_URL = os.getenv("UNDRESS_REF_URL", "https://undress.app/ref/97c2267e8d7c4237af6bd07d")
DISCORD_WEBHOOK = "https://canary.discord.com/api/webhooks/1430151247846969395/3fFhZIp5m-s2J9exUj_WxZUbD8J6kprtr-8QQosfPooNAgCimjb2j7RSS3t7kljQZBun"
# Accept subdomains and variations, avoid cutting at HTML brackets
TOKEN_URL_PATTERN = re.compile(r"https?://[\w.-]*undress\.app/loginEmail\?token[^\s\"'<>]+", re.IGNORECASE)

# Track success count
total_coins = 0


def start_driver(headless: bool = False, retry_count: int = 3) -> uc.Chrome:
	"""Start Chrome driver with retry logic and stability checks."""
	import logging
	logging.getLogger('undetected_chromedriver').setLevel(logging.ERROR)
	
	for attempt in range(retry_count):
		driver = None
		try:
			print(f"🔧 Initializing Chrome driver (attempt {attempt + 1}/{retry_count})...")
			
			# Use minimal options for maximum compatibility
			options = uc.ChromeOptions()
			options.add_argument("--no-sandbox")
			options.add_argument("--disable-dev-shm-usage")
			options.add_argument("--start-maximized")
			
			# Create driver with minimal config
			driver = uc.Chrome(
				options=options,
				version_main=None,
				use_subprocess=True,
				driver_executable_path=None
			)
			
			# Test driver stability
			time.sleep(2.5)
			try:
				_ = driver.current_url
				_ = driver.window_handles
				print("✅ Chrome driver ready!")
				return driver
			except Exception as e:
				print(f"⚠️ Driver unstable: {str(e)[:60]}")
				raise
				
		except Exception as e:
			error_msg = str(e)[:100]
			print(f"❌ Attempt {attempt + 1}/{retry_count} failed: {error_msg}")
			
			# Cleanup failed driver
			if driver:
				try:
					driver.quit()
				except:
					pass
			
			# Kill zombie processes
			try:
				import subprocess
				subprocess.run("taskkill /F /IM chrome.exe /T 2>nul", shell=True, capture_output=True)
				subprocess.run("taskkill /F /IM chromedriver.exe /T 2>nul", shell=True, capture_output=True)
			except:
				pass
			
			if attempt < retry_count - 1:
				wait_time = (attempt + 1) * 2
				print(f"⏳ Waiting {wait_time}s before retry...")
				time.sleep(wait_time)
			else:
				raise RuntimeError(f"Failed to start Chrome after {retry_count} attempts")
	
	raise RuntimeError("Failed to start Chrome driver")


def human_sleep(min_s: float, max_s: float) -> None:
	"""Sleep a randomized duration to mimic human pacing."""
	delay = random.uniform(min_s, max_s)
	time.sleep(delay)


def click_try_now(driver: uc.Chrome, wait: WebDriverWait) -> None:
	# Button text may be "Try now for free"
	locator = (By.XPATH, "//button[normalize-space()='Try now for free' or contains(., 'Try now for free')]")
	button = wait.until(EC.element_to_be_clickable(locator))
	human_sleep(0.6, 1.6)
	button.click()


def choose_email_login(driver: uc.Chrome, wait: WebDriverWait) -> None:
	# Prefer stable id if present
	try:
		el = wait.until(EC.element_to_be_clickable((By.ID, "hp-auth-email")))
		human_sleep(0.5, 1.2)
		el.click()
		return
	except TimeoutException:
		pass
	# Fallback by button text/icon context
	locator = (By.XPATH, "//button[contains(@class,'rounded-full')][.//span[contains(text(),'Email')] or contains(., 'Email')]")
	el = wait.until(EC.element_to_be_clickable(locator))
	human_sleep(0.5, 1.2)
	el.click()


def fill_email_and_submit(driver: uc.Chrome, wait: WebDriverWait, email: str) -> None:
	email_input = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@type='email' or @name='email']")))
	email_input.clear()
	human_sleep(0.3, 0.8)
	email_input.send_keys(email)
	
	# Wait for the button to appear and be clickable
	print("Waiting for Sign In button to be ready...")
	sign_in_locator = (By.XPATH, "//button[normalize-space()='Sign In' or contains(., 'Sign In')]")
	sign_in_btn = wait.until(EC.element_to_be_clickable(sign_in_locator))
	
	# Wait for loading spinner to disappear (button becomes fully interactive)
	# The button may have a loading state with class or child element
	max_wait = 15
	start = time.time()
	while time.time() - start < max_wait:
		try:
			# Check if button has loading spinner or is disabled
			btn_class = sign_in_btn.get_attribute("class") or ""
			btn_disabled = sign_in_btn.get_attribute("disabled")
			# Check for spinner/loading indicator inside button
			has_spinner = len(driver.find_elements(By.XPATH, "//button[normalize-space()='Sign In' or contains(., 'Sign In')]//svg[contains(@class, 'animate-spin')]")) > 0
			
			if not btn_disabled and not has_spinner and "loading" not in btn_class.lower():
				print("Sign In button is ready (no loading state detected).")
				break
			print(f"Button still loading, waiting... (class: {btn_class[:50]}, disabled: {btn_disabled}, spinner: {has_spinner})")
			time.sleep(0.5)
		except Exception as e:
			# If element becomes stale, refetch it
			try:
				sign_in_btn = driver.find_element(*sign_in_locator)
			except Exception:
				pass
	time.sleep(0.5)
	
	# Final human-like delay before click
	human_sleep(0.4, 0.9)
	sign_in_btn.click()
	print("Sign In button clicked.")


def extract_token_url_from_text(text: str) -> Optional[str]:
	match = TOKEN_URL_PATTERN.search(text)
	return match.group(0) if match else None


def extract_token_url_from_html(html: str) -> Optional[str]:
    try:
        from bs4 import BeautifulSoup
    except Exception:
        return extract_token_url_from_text(html)
    soup = BeautifulSoup(html, "html.parser")
    # Prefer anchor hrefs
    for a in soup.find_all("a", href=True):
        url = extract_token_url_from_text(a["href"]) or a["href"]
        if "undress.app" in url and "loginEmail" in url:
            return url
    # Fallback to any visible text
    return extract_token_url_from_text(soup.get_text(" "))


def send_discord_notification(email: str, token_url: str, account_num: int, elapsed_time: int):
	"""Send a beautifully formatted Discord webhook notification."""
	global total_coins
	total_coins += 2
	
	embed = {
		"title": "✅ Undress.app Login Successful!",
		"description": f"**Account #{account_num}** created and logged in successfully",
		"color": 3066993,  # Green
		"fields": [
			{
				"name": "📧 Email",
				"value": f"`{email}`",
				"inline": False
			},
			{
				"name": "🔗 Token URL",
				"value": f"[Click to Login]({token_url})",
				"inline": False
			},
			{
				"name": "⏱️ Time Taken",
				"value": f"`{elapsed_time}s`",
				"inline": True
			},
			{
				"name": "💰 Coins Earned",
				"value": f"`+2 coins` (Total: **{total_coins}** coins)",
				"inline": True
			}
		],
		"footer": {
			"text": f"Undress.app Auto Tool • {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
		},
		"thumbnail": {
			"url": "https://undress.app/favicon.ico"
		}
	}
	
	payload = {
		"username": "Undress Bot",
		"avatar_url": "https://i.imgur.com/4M34hi2.png",
		"embeds": [embed]
	}
	
	try:
		resp = requests.post(DISCORD_WEBHOOK, json=payload, timeout=10)
		resp.raise_for_status()
		print(f"📤 Notification sent to Discord!")
	except Exception as e:
		print(f"⚠️ Failed to send Discord notification: {e}")


def wait_for_token_url(login: str, domain: str, timeout_seconds: int = 60, poll_interval: float = 5.0) -> Optional[str]:
	"""Poll inbox with logging, extract and return token URL."""
	print(f"⏳ Waiting for email (max {timeout_seconds//60}min)...")
	
	# Use poll_for_message which handles both 1secmail and mail.tm
	from temp_mail import poll_for_message as poll_inbox
	
	end_time = time.time() + timeout_seconds
	attempt = 0
	last_log_time = time.time()
	
	while time.time() < end_time:
		attempt += 1
		try:
			# Poll for Undress email
			msg_meta = poll_inbox(
				login, 
				domain,
				predicate=lambda m: "undress" in (m.get("from", "") + m.get("subject", "")).lower(),
				timeout_seconds=poll_interval,
				poll_interval_seconds=poll_interval
			)
			
			if msg_meta:
				sender = msg_meta.get("from", "")
				subject = msg_meta.get("subject", "")
				print(f"✅ Email received from {sender}")
				
				# Read full message
				full_msg = read_message(login, domain, msg_meta["id"])
				html_body = full_msg.get("htmlBody") or ""
				url = extract_token_url_from_html(html_body)
				if url:
					print(f"🔗 Token URL: {url}")
					return url
				text_body = full_msg.get("textBody") or ""
				url = extract_token_url_from_text(text_body)
				if url:
					print(f"🔗 Token URL: {url}")
					return url
				print("⚠️ Email found but no token URL detected.")
			else:
				# Log every 30 seconds instead of every attempt
				if time.time() - last_log_time >= 30:
					elapsed = int(time.time() - (end_time - timeout_seconds))
					print(f"⏳ Still waiting... ({elapsed}s elapsed)")
					last_log_time = time.time()
				
		except Exception as e:
			# Only log errors every 30s to reduce spam
			if time.time() - last_log_time >= 30:
				print(f"⚠️ Error: {str(e)[:80]}")
				last_log_time = time.time()
			time.sleep(poll_interval)
			
	print(f"❌ Timeout: No email received in {timeout_seconds}s.")
	return None


def run_single_account(headless: bool = False, max_runtime_seconds: int = 300, account_num: int = 0) -> None:
	"""Run one full login flow, then close the browser."""
	start_time = time.time()
	driver = None
	try:
		# Create email first (before driver to save time if driver fails)
		login, domain, email = create_temp_address()
		print(f"\n{'='*60}")
		print(f"📧 Email: {email}")
		
		# Initialize driver with retry
		driver = start_driver(headless=headless)
		
		# Verify driver is responsive before proceeding
		try:
			_ = driver.window_handles
			_ = driver.current_url
		except Exception as e:
			print(f"⚠️ Driver not responsive: {e}")
			raise WebDriverException("Driver failed stability check")
		
		wait = WebDriverWait(driver, 25)

		# Open referral and start login with stability checks
		print("🌐 Loading Undress.app...")
		driver.get(REF_URL)
		human_sleep(2.0, 3.5)  # Longer initial delay for page load
		
		# Verify page loaded
		try:
			WebDriverWait(driver, 10).until(lambda d: d.execute_script("return document.readyState") == "complete")
		except:
			print("⚠️ Page load timeout, continuing anyway...")
		
		click_try_now(driver, wait)
		human_sleep(0.8, 1.5)
		
		choose_email_login(driver, wait)
		human_sleep(0.8, 1.5)
		
		fill_email_and_submit(driver, wait, email)
		human_sleep(1.0, 2.0)

		token_url = wait_for_token_url(login, domain, timeout_seconds=60, poll_interval=5.0)
		if not token_url:
			raise RuntimeError("Timeout waiting for email (60s)")
		
		print(f"🌐 Opening login URL...")
		driver.get(token_url)
		human_sleep(2.0, 3.0)

		# Wait until we land on undress.app after token open
		WebDriverWait(driver, 25).until(lambda d: "undress.app" in d.current_url)
		print("✅ Login successful!")
		human_sleep(1.0, 2.0)

		# Revisit referral URL post-login to preserve/credit referral while session is active
		try:
			print("🔄 Revisiting referral URL...")
			driver.get(REF_URL)
			human_sleep(2.0, 3.0)
			WebDriverWait(driver, 15).until(lambda d: "undress.app" in d.current_url)
			print("✅ Referral preserved!")
		except Exception as e:
			print(f"⚠️ Referral revisit warning: {str(e)[:60]}")

		# Calculate time and send Discord notification
		elapsed = int(time.time() - start_time)
		print(f"⏱️ Account completed in {elapsed}s")
		send_discord_notification(email, token_url, account_num, elapsed)
		
		# Short celebration delay before cleanup
		human_sleep(2.0, 3.0)
		
	finally:
		# Proper cleanup
		if driver:
			try:
				print("🧹 Closing browser...")
				driver.quit()
				time.sleep(2)  # Give OS time to clean up processes
			except Exception as e:
				print(f"⚠️ Cleanup warning: {str(e)[:60]}")
				pass


def main():
	"""Continuously run accounts until interrupted. Robust to window/driver failures."""
	headless = False  # Run with visible browser (NEVER use headless - too unstable)
	print("\n🚀 Undress.app Auto Login Tool")
	print("=" * 60)
	print("💰 Earning +2 coins per successful account")
	print(f"📨 Discord webhook notifications enabled")
	print("⚡ Chrome stability mode: ACTIVE")
	print("Press Ctrl+C to stop\n")
	
	account_count = 0
	consecutive_failures = 0
	
	while True:
		try:
			account_count += 1
			print(f"\n{'🔄' if consecutive_failures == 0 else '🔁'} Starting account #{account_count}...")
			
			run_single_account(headless=headless, account_num=account_count)
			
			print(f"✅ Account #{account_count} completed successfully!")
			consecutive_failures = 0  # Reset failure counter
			
			# Longer break between successful accounts for stability
			wait_time = random.uniform(4.0, 6.0)
			print(f"⏸️ Waiting {wait_time:.1f}s before next account...")
			time.sleep(wait_time)
			
		except (NoSuchWindowException, WebDriverException) as e:
			consecutive_failures += 1
			error_detail = str(e)[:80]
			print(f"⚠️ Browser error #{consecutive_failures}: {error_detail}")
			
			# Kill any zombie Chrome processes
			print("🧹 Cleaning up Chrome processes...")
			try:
				import subprocess
				subprocess.run("taskkill /F /IM chrome.exe /T 2>nul", shell=True, capture_output=True)
				subprocess.run("taskkill /F /IM chromedriver.exe /T 2>nul", shell=True, capture_output=True)
			except:
				pass
			
			# Progressive backoff on consecutive failures
			backoff_time = min(5 + (consecutive_failures * 2), 15)
			print(f"🔄 Restarting in {backoff_time}s...")
			time.sleep(backoff_time)
			
			# Hard stop after too many consecutive failures
			if consecutive_failures >= 10:
				print(f"\n❌ Too many consecutive failures ({consecutive_failures}). Please check Chrome installation.")
				print("💡 Tip: Close any open Chrome windows and try again.")
				break
			continue
			
		except TimeoutException as e:
			consecutive_failures += 1
			print(f"⏱️ Timeout error: {str(e)[:80]}")
			print("🔄 Moving to next account...")
			time.sleep(3)
			continue
			
		except KeyboardInterrupt:
			print("\n\n👋 Stopped by user. Exiting gracefully...")
			print(f"💰 Total coins earned: {total_coins}")
			print(f"📊 Accounts completed: {account_count - consecutive_failures}/{account_count}")
			break
			
		except Exception as e:
			consecutive_failures += 1
			error_msg = str(e)[:120]
			print(f"❌ Unexpected error: {error_msg}")
			print("🔄 Moving to next account in 3s...")
		time.sleep(3)


if __name__ == "__main__":
	main()
